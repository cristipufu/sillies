"""Retain bounded public-input qualification evidence and checked test receipts."""
import gzip
import hashlib
import json
import re
from pathlib import Path

ROOT = Path('/tmp/sillies-neural-integration-20261115')
DEST = Path('docs/reports/data/learned-speech-validation-2026-11-15')
DEST.mkdir(parents=True, exist_ok=True)
records = []

def retain(name, data):
    encoded = gzip.compress(data, compresslevel=9, mtime=0)
    target = DEST / (name + '.gz')
    target.write_bytes(encoded)
    records.append(dict(file=target.name, bytes=len(encoded), sha256=hashlib.sha256(encoded).hexdigest(), uncompressedBytes=len(data), uncompressedSHA256=hashlib.sha256(data).hexdigest()))

for path in sorted(ROOT.iterdir()):
    if path.is_file() and path.suffix in {'.json', '.py', '.txt'}:
        if path.name == 'DEMAND.txt':
            continue
        retain(path.name, path.read_bytes())
for relative in ['development-source/manifest.json', 'development-conditions/manifest.json', 'independent-noise/manifest.json']:
    retain(relative.replace('/', '-'), (ROOT / relative).read_bytes())

logs = [
    'baseline-development', 'candidate-development', 'scoped-development',
    'baseline-independent-noise', 'candidate-independent-noise', 'scoped-independent-noise',
    'long-window-development', 'preflight', 'final-check', 'final-stress', 'final-race',
    'final-release-build',
]
summary = {}
for label in logs:
    path = Path('/tmp/sillies-neural-' + label + '.log')
    data = path.read_bytes()
    retain(label + '.log', data)
    if label not in {'final-check', 'final-stress', 'final-race'}:
        continue
    log = data.decode()
    paths = re.findall(r'^Test receipts: (.+)$', log, flags=re.M)
    assert paths, label
    runs = []
    for receipt in paths:
        directory = Path(receipt)
        verified = json.loads((directory / 'verified.json').read_text())
        runs.append(dict(directory=directory.name, files={p.name:p.read_text() for p in sorted(directory.iterdir()) if p.name != 'timings.json' and p.suffix in {'.json', '.jsonl'}}))
        assert all(v.get('presentation') == 'headless' or (v['framework'] == 'xctest' and v['bundle'] in {'SilliesModelStoreTests', 'SilliesSpeechTests', 'SilliesTextModelsTests'}) for v in verified)
    counts = [int(value) for value in re.findall(r'Verified completion of (\d+) selected tests', log)]
    actual = sum(v['tests'] for r in runs for v in json.loads(r['files']['verified.json']))
    assert actual == sum(counts), (label, actual, counts)
    summary[label] = dict(verifiedTests=actual, verifiedRuns=sum(len(json.loads(r['files']['verified.json'])) for r in runs), receiptDirectories=paths)
    retain(label + '-completion-evidence.json', (json.dumps(runs, separators=(',', ':')) + '\n').encode())
retain('verification-summary.json', (json.dumps(summary, indent=2) + '\n').encode())
assert sum(p.stat().st_size for p in DEST.iterdir()) < 2 * 1024 * 1024
(DEST / 'checksums.json').write_text(json.dumps(dict(schema=1, artifacts=records), indent=2) + '\n')
print(json.dumps(summary, indent=2))
print('Compressed evidence bytes:', sum(p.stat().st_size for p in DEST.iterdir()))
