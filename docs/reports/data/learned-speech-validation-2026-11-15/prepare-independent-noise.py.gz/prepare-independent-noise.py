from pathlib import Path
import hashlib,io,json,struct,urllib.request,wave,zipfile
ROOT=Path('/tmp/sillies-neural-integration-20261115');OUT=ROOT/'independent-noise';OUT.mkdir(exist_ok=False)
RECORD=json.loads((ROOT/'demand-record.json').read_text())
class RemoteZip(io.RawIOBase):
 def __init__(self,url,size):self.url=url;self.size=size;self.position=0;self.downloaded=0
 def seekable(self):return True
 def tell(self):return self.position
 def seek(self,offset,whence=0):
  self.position=offset if whence==0 else self.position+offset if whence==1 else self.size+offset
  if not 0<=self.position<=self.size:raise ValueError('ZIP seek outside published source')
  return self.position
 def read(self,count=-1):
  count=min(self.size-self.position,count if count>=0 else self.size-self.position)
  if count==0:return b''
  if count>12*1024*1024:raise ValueError('ZIP range outside extraction bound')
  start=self.position;end=start+count-1
  request=urllib.request.Request(self.url,headers={'Range':f'bytes={start}-{end}'})
  with urllib.request.urlopen(request,timeout=60) as response:
   if response.status!=206 or not response.headers.get('Content-Range','').startswith(f'bytes {start}-{end}/'):raise ValueError('Source does not honor range request')
   data=response.read(count+1)
  if len(data)!=count:raise ValueError('Truncated ZIP range')
  self.downloaded+=len(data);self.position+=len(data);return data
fixtures=[];sources=[]
for scene in ['DWASHING','NRIVER']:
 item=next(v for v in RECORD['files'] if v['key']==scene+'_16k.zip');url='https://zenodo.org/records/1227121/files/'+item['key']+'?download=1';remote=RemoteZip(url,item['size'])
 with zipfile.ZipFile(remote) as archive:
  names=[n for n in archive.namelist() if n.endswith('/ch01.wav')];assert len(names)==1
  info=archive.getinfo(names[0]);assert info.file_size<=12*1024*1024;source=archive.read(names[0]);assert len(source)==info.file_size
 sourcePath=OUT/(scene+'-ch01-source.wav');sourcePath.write_bytes(source)
 with wave.open(io.BytesIO(source)) as w:
  assert (w.getframerate(),w.getnchannels(),w.getsampwidth())==(16000,1,2);total=w.getnframes();pcm=w.readframes(total)
 sourceSHA=hashlib.sha256(source).hexdigest();sources.append({'scene':scene,'sourceURL':url,'publishedArchiveBytes':item['size'],'publishedArchiveChecksum':item['checksum'],'archiveChecksumVerified':False,'member':names[0],'zipCRC32Verified':True,'memberSHA256':sourceSHA,'rangeBytesDownloaded':remote.downloaded})
 for second in [0,60,120,180,240]:
  count=128000;start=second*16000;assert start+count<=total;data=pcm[start*2:(start+count)*2];p=OUT/(scene+'-'+str(second)+'.wav')
  with wave.open(str(p),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(data)
  for language in ['en','ro']:
   fixtures.append({'id':f'demand-{scene}-{second}::{language}','language':language,'split':'test','condition':'independent-noise','file':p.name,'reference':'','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_sha256':sourceSHA,'sourceStartSample':start,'sourceSampleCount':count})
(ROOT/'independent-noise-source-manifest.json').write_text(json.dumps({'dataset':'DEMAND 1.0, Zenodo 1227121','license':'CC BY-SA 3.0','authors':['Joachim Thiemann','Nobutaka Ito','Emmanuel Vincent'],'selection':'Two publisher-described non-speech environments: washing machine and running creek. Channel 1, complete 8s intervals at 0/60/120/180/240s; selected before recognition; no MUSAN sources. Corpus context labels are used, not a claim of manually annotated speech absence.','sources':sources},indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps({'fixtures':fixtures},indent=2)+'\n');print('Prepared',len(fixtures),'independent-noise language pairs')
