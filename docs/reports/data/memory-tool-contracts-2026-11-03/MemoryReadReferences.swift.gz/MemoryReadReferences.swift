import Foundation
import SilliesCore

/// One tool turn owns the revisions it actually read. Storage still checks them atomically.
actor MemoryReadReferences {
  private var references: [UUID: CompanionMemory.Reference] = [:]

  func record(_ memories: [CompanionMemory]) {
    for memory in memories { references[memory.id] = memory.reference }
  }

  func reference(for id: UUID) -> CompanionMemory.Reference? { references[id] }
}
