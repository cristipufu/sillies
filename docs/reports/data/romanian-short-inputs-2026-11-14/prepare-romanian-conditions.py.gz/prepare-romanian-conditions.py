from pathlib import Path
import hashlib,importlib.util,json,random
root=Path('/tmp/sillies-whisper-followup-20261114');source=root/'romanian-short/manifest.json';out=root/'romanian-conditions';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('quality',Path('Benchmarks/Speech/prepare-quality.py'));q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
fixtures=[]
for item in json.loads(source.read_text())['fixtures']:
 path=source.parent/item['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'];values=q.samples(path);seed=int(hashlib.sha256(item['id'].encode()).hexdigest()[:16],16)
 for condition in ['clean','quiet','noise']:
  target=out/(item['id']+'--'+condition+'.wav');q.write_audio(target,q.transformed(values,condition,seed));sha=hashlib.sha256(target.read_bytes()).hexdigest()
  for language in ['ro','auto']:
   fixtures.append({**item,'id':item['id']+'::'+language+'-'+condition,'file':target.name,'language':language,'condition':'short-'+condition,'sha256':sha})
for level in [0,.0018,.015]:
 rng=random.Random(20261117);target=out/('no-speech-'+str(level)+'.wav');q.write_audio(target,[rng.gauss(0,level) for _ in range(14400)])
 for language in ['ro','auto']:
  fixtures.append({'id':'ro-short-noise-'+str(level)+'::'+language,'language':language,'condition':'no-speech','split':'test','reference':'','file':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
manifest={'sourceManifestSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'selection':'All 26 selected complete Romanian lexical recordings, original/quiet/noise, each with explicit Romanian and automatic language; three new 0.9s noise controls in both modes; no added silence or trimming.','fixtures':fixtures};(out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
contract={'baseline':'Pre-short-fix 47ed667 executable, baseline boundary arm','candidate':'Shipped 01ab624 executable, baseline boundary arm','gate':'Existing raw cross-version gate; require fewer errors, negative upper clustered-bootstrap bound, no language/condition or critical-loss/noise-final/draft regression. No transcript rewriting or adjusted effects.','scope':'Complete short Romanian lexical clips, explicit and automatic language. Three public contributor labels, 16/9/1 files; no conversational or population-wide language accuracy claim. No source or threshold changes after outcomes.'};(root/'romanian-acceptance-contract.json').write_text(json.dumps(contract,indent=2)+'\n');print(len(fixtures),'paired conditions')
