from pathlib import Path
import collections,time,urllib.error,hashlib,html,json,re,subprocess,urllib.parse,urllib.request,wave
ROOT=Path('/tmp/sillies-whisper-followup-20261114');DEST=ROOT/'romanian-short';DEST.mkdir(exist_ok=True)
TERMS=['da','nu','bine','gata','salut','pa','scuze','mulțumesc','te rog','sigur','corect','exact','acum','aici','azi','mâine','unu','doi','trei','patru','cinci','șase','șapte','opt','nouă','zece']
PLAN={'selection':'Fixed short replies, time/place words and numbers; exact structured Romanian spoken-text labels, complete original recordings of 0.2–1.0s, no trimming; at most 16 per public speaker, up to 48 total. Selection and conditioning precede all recognition. Require at least 24 recordings and three speakers, otherwise retain selection failure and revise inputs before any ASR.','terms':TERMS,'source':'https://commons.wikimedia.org/wiki/Category:Lingua_Libre_pronunciation-ron','licenses':['CC BY 4.0','CC BY-SA 4.0']}
(ROOT/'romanian-selection-plan.json').write_text(json.dumps(PLAN,indent=2,ensure_ascii=False)+'\n')

def api(arguments,name):
 if (ROOT/name).exists():return json.loads((ROOT/name).read_text())
 url='https://commons.wikimedia.org/w/api.php?'+urllib.parse.urlencode({'format':'json',**arguments})
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sillies speech qualification https://github.com/cristipufu/sillies'}),timeout=45) as response:data=response.read(8*1024*1024+1)
 if len(data)>8*1024*1024:raise ValueError('Metadata outside bound')
 value=json.loads(data);(ROOT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
 if 'error' in value:raise ValueError(value['error'])
 return value

candidates=[];seen=set()
for index,term in enumerate(TERMS):
 data=api({'action':'query','generator':'search','gsrsearch':f'incategory:"Lingua Libre pronunciation-ron" intitle:"-{term}.wav"','gsrnamespace':6,'gsrlimit':50,'prop':'videoinfo','viprop':'url|size|sha1|extmetadata'},f'commons-search-{index}.json')
 for page in sorted(data.get('query',{}).get('pages',{}).values(),key=lambda v:v['title']):
  info=page.get('videoinfo',[{}])[0]
  if page['pageid'] in seen or not .2<=info.get('duration',0)<=1 or info.get('size',0)>1000000:continue
  if info.get('extmetadata',{}).get('LicenseShortName',{}).get('value') not in PLAN['licenses']:continue
  if not page['title'].endswith('-'+term+'.wav'):continue
  seen.add(page['pageid']);candidates.append((page,term))
 print('Metadata term',index+1,'candidates',len(candidates),flush=True)
fixtures=[];speakers=collections.Counter()
for offset in range(0,len(candidates),40):
 group=candidates[offset:offset+40];data=api({'action':'wbgetentities','ids':'|'.join('M'+str(v['pageid']) for v,_ in group),'props':'labels|claims'},f'commons-structured-{offset}.json')
 for page,term in group:
  entity=data['entities']['M'+str(page['pageid'])];statements=entity.get('statements',{})
  texts=[s['mainsnak'].get('datavalue',{}).get('value') for s in statements.get('P9533',[])]
  if texts!=[{'text':term,'language':'ro'}]:continue
  info=page['videoinfo'][0];speaker=page['title'].split('-',3)[2]
  if speakers[speaker]>=16 or len(fixtures)>=48:continue
  sourceURL=urllib.parse.urlunsplit(urllib.parse.urlsplit(info['url'])._replace(query='',fragment=''))
  original=DEST/('commons-ro-'+str(page['pageid'])+'-source.wav')
  if original.exists():source=original.read_bytes()
  else:
   for attempt in range(4):
    try:
     time.sleep(1)
     with urllib.request.urlopen(urllib.request.Request(sourceURL,headers={'User-Agent':'Sillies speech qualification https://github.com/cristipufu/sillies'}),timeout=45) as response:source=response.read(1000001)
     break
    except urllib.error.HTTPError as failure:
     if failure.code!=429 or attempt==3:raise
     delay=min(30,max(10,int(failure.headers.get('Retry-After','10'))));print('Rate limited; retry in',delay,flush=True);time.sleep(delay)
  if len(source)!=info['size'] or hashlib.sha1(source).hexdigest()!=info['sha1']:raise ValueError('Wikimedia source changed')
  identifier='commons-ro-'+str(page['pageid']);original=DEST/(identifier+'-source.wav');audio=DEST/(identifier+'.wav');original.write_bytes(source)
  if audio.exists():audio.unlink()
  subprocess.run(['ffmpeg','-nostdin','-v','error','-i',str(original),'-ac','1','-ar','16000','-c:a','pcm_s16le','-map_metadata','-1','-fflags','+bitexact','-flags:a','+bitexact',str(audio)],check=True)
  with wave.open(str(audio),'rb') as file:count=file.getnframes();assert file.getframerate()==16000 and file.getnchannels()==1 and file.getsampwidth()==2
  if not 3200<=count<=16000:raise ValueError('Whole recording outside reviewed short bound')
  speakers[speaker]+=1
  fixtures.append({'id':identifier,'language':'ro','split':'test','condition':'short-clean','file':audio.name,'reference':term,'speaker':speaker,'sourcePage':info['descriptionurl'],'sourceURL':sourceURL,'source_sha1':info['sha1'],'source_sha256':hashlib.sha256(source).hexdigest(),'sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'duration':count/16000,'sampleCount':count,'license':info['extmetadata']['LicenseShortName']['value'],'licenseURL':info['extmetadata']['LicenseUrl']['value'],'author':html.unescape(re.sub('<[^>]+>',' ',info['extmetadata']['Artist']['value'])),'structuredTextProperty':'P9533','structuredLanguage':'ro','canonicalization':'Complete original audio resampled by ffmpeg to mono PCM16 16kHz; no gain change or trimming.'})
manifest={**PLAN,'speakers':dict(speakers),'ffmpegVersion':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0],'fixtures':fixtures};(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n');print('SELECTED',len(fixtures),dict(speakers),flush=True)

assert len(fixtures)>=24 and len(speakers)>=3,(len(fixtures),speakers)
