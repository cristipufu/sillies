from pathlib import Path
import gzip,hashlib,json
ROOT=Path('/tmp/sillies-whisper-followup-20261114')
DESTINATION=Path('docs/reports/data/whisper-long-window-noise-2026-11-14')
MAX_INPUT_BYTES=8*1024*1024
MAX_ARCHIVE_BYTES=2*1024*1024
patterns=['acoustic-*.json','confidence-*.json','real-noise-*.json','neural-vad*.json','musan-*.json','musan-*.txt','long-*.json','*real-noise*.py','prepare-analysis-probe.py','shipped-freeze.json','fresh-input-audit.json','native-quality-completions.json','production-review.json','final-test-receipts.json','final-helper-source.json','qualification-environment.json','archive-long-evidence.py']
files={f for pattern in patterns for f in ROOT.glob(pattern)}
files.update(ROOT/name/'manifest.json' for name in ['long-development-source','long-development-conditions','long-fresh-source','long-fresh-conditions','real-noise'])
files.update(Path('/tmp').glob('sillies-whisper-followup-*.log'))
DESTINATION.mkdir(parents=True,exist_ok=True)
rows=[]
for path in sorted(files):
 data=path.read_bytes();assert len(data)<=MAX_INPUT_BYTES
 name=(str(path.relative_to(ROOT)).replace('/','--') if path.is_relative_to(ROOT) else path.name)+'.gz'
 compressed=gzip.compress(data,mtime=0);(DESTINATION/name).write_bytes(compressed)
 rows.append({'file':name,'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'uncompressedBytes':len(data),'uncompressedSHA256':hashlib.sha256(data).hexdigest()})
assert len(rows)==len({v['file'] for v in rows})
assert sum(v['bytes'] for v in rows)<=MAX_ARCHIVE_BYTES
(DESTINATION/'checksums.json').write_text(json.dumps({'schema':1,'scope':'Public research qualification only. Failures retained; no audio, model weights or executable binaries.','artifacts':rows},indent=2)+'\n')
for row in rows:
 data=(DESTINATION/row['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];assert hashlib.sha256(gzip.decompress(data)).hexdigest()==row['uncompressedSHA256']
print('Archived',len(rows),'verified artifacts;',sum(v['bytes'] for v in rows),'bytes')
