from pathlib import Path
import hashlib,importlib.util,json
r=Path('/tmp/sillies-whisper-followup-20261114');out=r/'analysis-normalized-controls';out.mkdir(exist_ok=False);spec=importlib.util.spec_from_file_location('quality',Path('Benchmarks/Speech/prepare-quality.py'));q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q);m=r/'real-noise/manifest.json';fixtures=[]
for f in json.loads(m.read_text())['fixtures']:
 if f['condition']!='real-noise-original' or f['language']!='en':continue
 values=q.samples(m.parent/f['file']);rms=(sum(v*v for v in values)/len(values))**.5;peak=max(abs(v) for v in values);gain=min(1,.024/max(rms,1e-9),.125/max(peak,1e-9));p=out/(f['id'].split('::')[0]+'.wav');q.write_audio(p,[v*gain for v in values]);fixtures.append({'id':f['id'],'audio':p.as_uri(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expectedSpeech':False})
base=json.loads((r/'acoustic-real-noise-probe-v2.json').read_text());fixtures += [v for v in base['fixtures'] if not v['id'].startswith('noise-')];(r/'acoustic-analysis-normalized-probe.json').write_text(json.dumps({'fixtures':fixtures,'output':(r/'acoustic-analysis-normalized-probe-results.json').as_uri()},indent=2)+'\n')
