from pathlib import Path
import hashlib,importlib.util,json,re,urllib.request
root=Path('/tmp/sillies-whisper-followup-20261114');out=root/'real-noise';out.mkdir(exist_ok=True);revision=json.loads((root/'musan-repository.json').read_text())['revision'];tree={v['path']:v for v in json.loads((root/'musan-tree-noise-sound-bible.json').read_text())};text=(root/'musan-sound-bible-license.txt').read_text();credits={}
for block in text.split('========================================================================'):
 match=re.search(r'noise-sound-bible-(\d+)',block)
 if match:credits[int(match[1])]=block.strip()
selected=[1,4,7,10,14,17,28,29,30,32,33,38,39,49,58,60,61,62,63,66,67,70,74,77]
spec=importlib.util.spec_from_file_location('quality',Path('Benchmarks/Speech/prepare-quality.py'));q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
(root/'real-noise-selection-plan.json').write_text(json.dumps({'ids':selected,'selection':'Fixed corpus-labeled non-speech devices/environmental recordings selected by title before any model output. Complete source verified against pinned repository LFS hash; first up to 12s in original and RMS .0018 conditions. Each with English and Romanian hints. No crowd, conversation, music or vocal-event selections.','revision':revision},indent=2)+'\n')
fixtures=[]
for identifier in selected:
 name=f'noise-sound-bible-{identifier:04}';path='noise/sound-bible/'+name+'.wav';entry=tree[path];assert entry['size']<=4*1024*1024
 with urllib.request.urlopen('https://huggingface.co/datasets/FluidInference/musan/resolve/'+revision+'/'+path,timeout=45) as response:data=response.read(4*1024*1024+1)
 sha=hashlib.sha256(data).hexdigest();assert len(data)==entry['size'] and sha==entry['lfs']['oid'];original=out/(name+'-source.wav');original.write_bytes(data);values=q.samples(original)[:192000]
 for condition in ['original','quiet']:
  target=out/(name+'-'+condition+'.wav');rms=(sum(v*v for v in values)/len(values))**.5;gain=1 if condition=='original' else .0018/max(rms,1e-9);q.write_audio(target,[v*gain for v in values]);outputSHA=hashlib.sha256(target.read_bytes()).hexdigest()
  for language in ['en','ro']:
   fixtures.append({'id':name+'::'+condition+'-'+language,'language':language,'split':'test','condition':'real-noise-'+condition,'reference':'','file':target.name,'sha256':outputSHA,'source_sha256':sha,'sourceURL':'https://huggingface.co/datasets/FluidInference/musan/resolve/'+revision+'/'+path,'duration':len(values)/16000,'sourceCredit':credits[identifier]})
manifest={'dataset':'MUSAN noise/sound-bible','mirrorRevision':revision,'fixtures':fixtures};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(fixtures),'real-noise paired controls')
