from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/sillies-offline-20261114');destination=Path('docs/reports/data/whisper-short-inputs-2026-11-14');destination.mkdir(parents=True,exist_ok=True)
files=[f for f in root.rglob('*') if f.is_file() and not f.is_symlink() and f.suffix in ['.json','.py','.txt'] and f.name!='call-resource-audit.json']
files+=list(Path('/tmp').glob('sillies-offline-*.log'))
artifacts=[];seen=set()
for f in sorted(files):
 name=(str(f.relative_to(root)).replace('/','--') if f.is_relative_to(root) else 'logs--'+f.name)+'.gz'
 assert name not in seen;seen.add(name);data=f.read_bytes();assert len(data)<=20*1024*1024
 zipped=gzip.compress(data,mtime=0);out=destination/name;out.write_bytes(zipped)
 artifacts.append({'file':name,'bytes':len(zipped),'sha256':hashlib.sha256(zipped).hexdigest(),'uncompressedBytes':len(data),'uncompressedSHA256':hashlib.sha256(data).hexdigest()})
assert sum(a['bytes'] for a in artifacts)<2*1024*1024
(destination/'checksums.json').write_text(json.dumps({'schema':1,'scope':'Public audio qualification evidence only; no model weights or audio files. Raw failures and repeated baseline results retained.','artifacts':artifacts},indent=2)+'\n')
for a in artifacts:
 data=(destination/a['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==a['sha256'];assert hashlib.sha256(gzip.decompress(data)).hexdigest()==a['uncompressedSHA256']
print('Archived and verified',len(artifacts),'files;',sum(a['bytes'] for a in artifacts),'compressed bytes')
