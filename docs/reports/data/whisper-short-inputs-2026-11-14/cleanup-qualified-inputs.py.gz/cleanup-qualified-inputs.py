from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/tmp/sillies-offline-20261114')
assert root.resolve()==Path('/private/tmp/sillies-offline-20261114')
probe=Path('/tmp/sillies-offline-pre-cleanup-open-files.txt');assert probe.exists() and not probe.read_bytes()
commands=subprocess.check_output(['ps','-axo','comm='],text=True).splitlines()
assert not any(c.startswith(str(root)+'/SpeechBenchmark-') for c in commands)
for freeze,binary in [('baseline-freeze.json','SpeechBenchmark-baseline'),('final-freeze.json','SpeechBenchmark-final')]:
 assert hashlib.sha256((root/binary).read_bytes()).hexdigest()==json.loads((root/freeze).read_text())['binarySHA256']
directories=['source','conditions','meeting','continuous','short-noise','fresh-short-noise','acoustic-controls','short-holdout','short-holdout-conditions','holdout-source']
paths=[root/n for n in directories]+list(root.glob('SpeechBenchmark-*'))+[root/'validation-silence.wav']+list(root.glob('*.bundle'))
review=[]
for path in paths:
 assert path.parent==root and path.exists()
 if path.is_symlink():review.append({'path':str(path),'kind':'resource-symlink','bytes':0});path.unlink()
 elif path.is_dir():
  assert not any(f.is_symlink() for f in path.rglob('*'))
  review.append({'path':str(path),'kind':'generated-public-audio-directory','bytes':sum(f.stat().st_size for f in path.rglob('*') if f.is_file())});shutil.rmtree(path)
 else:review.append({'path':str(path),'kind':'generated-input-or-pinned-executable','bytes':path.stat().st_size});path.unlink()
(root/'cleanup.json').write_text(json.dumps({'openFilesCheck':str(probe),'openFiles':0,'noRunningQualificationExecutable':True,'removed':review,'removedBytes':sum(v['bytes'] for v in review),'preserved':'Source and checksum manifests, raw results, scripts, source snapshots and completion receipts. Installed models, personal Vault, build caches and the existing single rollback bundle were outside this cleanup.'},indent=2)+'\n')
print('Removed',len(paths),'verified paths;',sum(v['bytes'] for v in review),'bytes')
