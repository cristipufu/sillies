from pathlib import Path
import hashlib,json,urllib.request,wave
root=Path('/tmp/sillies-offline-20261114');dest=root/'holdout-source';dest.mkdir(exist_ok=False)
records=[]
for meeting in ['ES2002b','ES2002c']:
 url=f'https://groups.inf.ed.ac.uk/ami/AMICorpusMirror/amicorpus/{meeting}/audio/{meeting}.Mix-Headset.wav'
 path=dest/f'{meeting}.Mix-Headset.wav';temporary=path.with_suffix('.part');digest=hashlib.sha256();size=0
 with urllib.request.urlopen(url,timeout=60) as response,temporary.open('wb') as output:
  while chunk:=response.read(1024*1024):
   size+=len(chunk)
   if size>96*1024*1024:raise ValueError('Source exceeds explicit download bound')
   digest.update(chunk);output.write(chunk)
 with wave.open(str(temporary)) as audio:assert (audio.getframerate(),audio.getnchannels(),audio.getsampwidth())==(16000,1,2)
 temporary.rename(path);records.append({'meeting':meeting,'source_url':url,'sha256':digest.hexdigest(),'bytes':size});print(meeting,size,digest.hexdigest(),flush=True)
(root/'holdout-source-inputs.json').write_text(json.dumps(records,indent=2)+'\n')
