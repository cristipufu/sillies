from pathlib import Path
import hashlib,json,random,struct,wave,math
root=Path('/tmp/sillies-offline-20261114');destination=root/'fresh-short-noise';destination.mkdir(exist_ok=False)
fixtures=[]
for seconds in [.2,.5,.95]:
 for level in [.002,.008,.02]:
  for kind in ['gaussian','hum','tone','clicks']:
   identifier=f'new-{kind}-{seconds}-{level}';rng=random.Random(20261114);count=round(seconds*16000)
   if kind=='gaussian': values=[rng.gauss(0,level) for _ in range(count)]
   elif kind=='hum': values=[level*(math.sin(2*math.pi*50*i/16000)+.4*math.sin(2*math.pi*100*i/16000)) for i in range(count)]
   elif kind=='tone': values=[level*math.sin(2*math.pi*440*i/16000) for i in range(count)]
   else: values=[level if i%320==0 else 0 for i in range(count)]
   pcm=struct.pack('<'+str(len(values))+'h',*(round(max(-1,min(1,x))*32767) for x in values));p=destination/(identifier+'.wav')
   with wave.open(str(p),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(pcm)
   fixtures.append({'id':identifier,'language':'en','split':'test','condition':kind,'file':str(p.relative_to(root)),'reference':'','sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
warm=json.loads((root/'short-noise-manifest.json').read_text())['fixtures'][0]
manifest={'selection':'Fresh non-speech controls fixed before transcription: four signal types, three lengths all below one second, three levels; no added silence. Require zero final/draft words and no failures for every short input.','fixtures':[warm]+fixtures}
(root/'fresh-short-noise-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(fixtures),'new short noise inputs')
