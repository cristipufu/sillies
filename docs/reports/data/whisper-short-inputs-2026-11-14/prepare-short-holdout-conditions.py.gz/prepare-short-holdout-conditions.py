from pathlib import Path
import hashlib,importlib.util,json
root=Path('/tmp/sillies-offline-20261114');source=root/'short-holdout/manifest.json';dest=root/'short-holdout-conditions';dest.mkdir(exist_ok=False)
s=importlib.util.spec_from_file_location('conditions',Path('Benchmarks/Speech/prepare-quality.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
fixtures=[]
for f in json.loads(source.read_text())['fixtures']:
 path=source.parent/f['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==f['sha256'];values=m.samples(path);seed=int(hashlib.sha256(f['id'].encode()).hexdigest()[:16],16)
 for condition in ['clean','quiet','noise']:
  target=dest/(f['id']+'--'+condition+'.wav');m.write_audio(target,m.transformed(values,condition,seed))
  fixtures.append({**f,'id':f['id']+'::'+condition,'condition':'short-'+condition,'file':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
manifest={'sourceManifestSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'selection':'All selected untouched short utterances in original, RMS-0.0012 quiet and seeded 10dB Gaussian noise conditions. No added silence; each input remains <=0.99s.','fixtures':fixtures};(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Prepared',len(fixtures),'held-out conditions.')
contract={'primary':'Cross-version raw score on all 117 untouched short conditions; select baseline mode from both executables. Require the unchanged strict WER and subgroup/critical-loss gates.','noise':'Zero newly generated final or live-draft words in newly eligible short noise inputs.','longerInputs':'Verify actual input and inference traces, preserve every longer-input sample/native option/seek/output acceptance by scoped regressions; retain all raw control outcomes, including stochastic variations. Do not normalize hypotheses or claim overall WER improvement from long controls.','limits':'English short-speech holdout; existing English/Romanian development and AMI longer speech controls; no live devices or GUI.'};(root/'scoped-acceptance-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
