from pathlib import Path
import hashlib,json,random,struct,wave
root=Path('/tmp/sillies-offline-20261114');destination=root/'short-noise';destination.mkdir(exist_ok=False)
fixtures=[]
for seed in [1501,1601]:
 for seconds in [.08,.16,.32,.64,.95]:
  for level in [.002,.008,.02]:
   name=f'burst-{seed}-{seconds}-{level}';rng=random.Random(seed)
   values=[0.0]*8000+[rng.gauss(0,level) for _ in range(round(seconds*16000))]+[0.0]*19200
   pcm=struct.pack('<'+str(len(values))+'h',*(round(max(-1,min(1,x))*32767) for x in values));p=destination/(name+'.wav')
   with wave.open(str(p),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(pcm)
   fixtures.append({'id':name,'language':'en','split':'test','condition':'short-noise','file':str(p.relative_to(root)),'reference':'','sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
warm=json.loads((root/'conditions/manifest.json').read_text())['fixtures'][0];warm={**warm,'file':'conditions/'+warm['file']}
manifest={'selection':'Consulted short-noise controls: two fixed Gaussian seeds, five burst lengths, three levels, leading 0.5s and trailing 1.2s silence. No speech.','fixtures':[warm]+fixtures}
(root/'short-noise-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
