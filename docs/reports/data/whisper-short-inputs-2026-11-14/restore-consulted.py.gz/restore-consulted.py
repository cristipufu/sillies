from pathlib import Path
import gzip,hashlib,importlib.util,json,subprocess
root=Path('/tmp/sillies-offline-20261114');prior=Path('docs/reports/data/whisper-transcription-2026-11-14')
def document(name): return json.loads(gzip.decompress((prior/(name+'.gz')).read_bytes()))
selected=[f for f in document('source-manifest.json')['fixtures'] if f['split']=='dev']
selected += [f for f in document('fresh-source-manifest.json')['fixtures'] if f['id'] in ['ro_ro-test-1893','ro_ro-test-1878']]
selected += [f for f in document('next-source-manifest.json')['fixtures'] if f['id']=='en_us-test-1850']
assert len(selected)==19 and len({f['id'] for f in selected})==19
manifest={'selection':'Consulted development and earlier failure controls only; no untouched validation recordings.','fixtures':selected}
p=root/'consulted-source-manifest.json';p.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
subprocess.run(['python3','-B','Benchmarks/Speech/prepare-fleurs.py',str(p),str(root/'source')],check=True)
subprocess.run(['python3','-B','Benchmarks/Speech/prepare-quality.py',str(root/'source/manifest.json'),str(root/'conditions')],check=True)
for name in ['meeting','continuous']:
 p=root/(name+'-source-manifest.json');p.write_text(json.dumps(document(name+'-source-manifest.json'),indent=2)+'\n')
 subprocess.run(['python3','-B','Benchmarks/Speech/prepare-ami.py',str(p),'/tmp/sillies-whisper-20261114/ami-source',str(root/name)],check=True)
