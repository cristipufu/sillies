"""Select short public utterances from fixed annotation rules before any recognizer output."""
from pathlib import Path
import hashlib,json,math,wave,xml.etree.ElementTree as ET,zipfile
root=Path('/tmp/sillies-offline-20261114');prior=Path('/tmp/sillies-whisper-20261114/ami-source')
base=json.loads((root/'meeting-source-manifest.json').read_text());excluded=[]
for name in ['meeting-source-manifest.json','continuous-source-manifest.json']:
 excluded += [(f['source_start_seconds'],f['source_end_seconds']) for f in json.loads((root/name).read_text())['fixtures']]
inputs=[{'meeting':'ES2002a','source_url':base['source_url'],'sha256':base['source_sha256'],'file':str(prior/'ES2002a.Mix-Headset.wav')}]
inputs += [{**f,'file':str(root/'holdout-source'/(f['meeting']+'.Mix-Headset.wav'))} for f in json.loads((root/'holdout-source-inputs.json').read_text())]
dest=root/'short-holdout';dest.mkdir(exist_ok=False);fixtures=[];counts={}
assert hashlib.sha256((prior/'annotations.zip').read_bytes()).hexdigest()==base['annotations_sha256']
with zipfile.ZipFile(prior/'annotations.zip') as archive:
 for source in inputs:
  path=Path(source['file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==source['sha256'];words=[]
  for name in sorted(archive.namelist()):
   if not name.endswith('.words.xml') or '/'+source['meeting']+'.' not in name:continue
   for node in ET.fromstring(archive.read(name)).iter('w'):
    if 'starttime' not in node.attrib or 'endtime' not in node.attrib or not node.text:continue
    start,end=float(node.attrib['starttime']),float(node.attrib['endtime']);text=node.text.strip()
    if math.isfinite(start) and math.isfinite(end) and 0<=start<end and any(c.isalnum() for c in text):words.append((start,end,text))
  words.sort();episodes=[]
  for word in words:
   if not episodes or word[0]-max(w[1] for w in episodes[-1])>=.2:episodes.append([])
   episodes[-1].append(word)
  selected=[]
  for episode in episodes:
   start=min(w[0] for w in episode)-.1;end=max(w[1] for w in episode)+.1
   if len(episode)>3 or not .2<end-start<=.99 or start<120:continue
   if source['meeting']=='ES2002a' and any(start<high and end>low for low,high in excluded):continue
   selected.append((start,end,' '.join(w[2] for w in episode)))
   if len(selected)==16:break
  counts[source['meeting']]=len(selected)
  with wave.open(str(path)) as audio:
   for i,(start,end,reference) in enumerate(selected):
    target=dest/f"ami-{source['meeting']}-short-unseen-{i}.wav";audio.setpos(round(start*16000));pcm=audio.readframes(round((end-start)*16000))
    with wave.open(str(target),'wb') as out:out.setnchannels(1);out.setsampwidth(2);out.setframerate(16000);out.writeframes(pcm)
    fixtures.append({'id':target.stem,'language':'en','split':'test','condition':'short-utterance','file':target.name,'reference':reference,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source_meeting':source['meeting'],'source_start_seconds':start,'source_end_seconds':end})
assert len(fixtures)>=24,(counts,len(fixtures))
manifest={'corpus':base['corpus'],'license':base['license'],'annotations_url':base['annotations_url'],'annotations_sha256':base['annotations_sha256'],'source_inputs':inputs,'selection':'Up to first 16 1-3-word episodes per ES2002a/b/c after 120s, separated by >=0.2s silence, 0.1s context each side, total >0.2s and <=0.99s. Excludes all previously transcribed AMI intervals. Selection made before recognizer outputs.','excluded_ES2002a_intervals':excluded,'fixtures':fixtures};(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Selected untouched short episodes:',counts,len(fixtures),flush=True)
