"""Select untouched short AMI utterances by annotation/time rules before recognition."""
from pathlib import Path
import hashlib,json,math,wave,xml.etree.ElementTree as ET,zipfile
root=Path('/tmp/sillies-offline-20261114');source=Path('/tmp/sillies-whisper-20261114/ami-source')
base=json.loads((root/'meeting-source-manifest.json').read_text());excluded=[]
for name in ['meeting-source-manifest.json','continuous-source-manifest.json']:
 excluded += [(f['source_start_seconds'],f['source_end_seconds']) for f in json.loads((root/name).read_text())['fixtures']]
words=[]
with zipfile.ZipFile(source/'annotations.zip') as archive:
 for name in sorted(archive.namelist()):
  if not name.endswith('.words.xml') or '/ES2002a.' not in name: continue
  for node in ET.fromstring(archive.read(name)).iter('w'):
   if 'starttime' not in node.attrib or 'endtime' not in node.attrib or not node.text: continue
   start,end=float(node.attrib['starttime']),float(node.attrib['endtime']);text=node.text.strip()
   if math.isfinite(start) and math.isfinite(end) and 0<=start<end and text: words.append((start,end,text))
words.sort();episodes=[]
for word in words:
 if not episodes or word[0]-max(w[1] for w in episodes[-1])>=.2:episodes.append([])
 episodes[-1].append(word)
selected=[]
for episode in episodes:
 start=min(w[0] for w in episode)-.1;end=max(w[1] for w in episode)+.1
 if len(episode)>3 or not .2<end-start<=.99 or start<120: continue
 if any(start<high and end>low for low,high in excluded): continue
 selected.append((start,end,' '.join(w[2] for w in episode)))
 if len(selected)==24:break
assert len(selected)==24,len(selected)
dest=root/'short-holdout';dest.mkdir(exist_ok=False);fixtures=[]
with wave.open(str(source/'ES2002a.Mix-Headset.wav')) as audio:
 for i,(start,end,reference) in enumerate(selected):
  path=dest/f'ami-ES2002a-short-unseen-{i}.wav';audio.setpos(round(start*16000));pcm=audio.readframes(round((end-start)*16000))
  with wave.open(str(path),'wb') as output:output.setparams(audio.getparams());output.writeframes(pcm)
  fixtures.append({'id':path.stem,'language':'en','split':'test','condition':'short-utterance','file':path.name,'reference':reference,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_start_seconds':start,'source_end_seconds':end})
manifest={**base,'selection':'First 24 1-3-word episodes separated by >=0.2s silence after 120s, 0.1s context each side, total >0.2s and <=0.99s, excluding every earlier AMI excerpt and continuous interval. Selected before this candidate transcribes them.','excluded_intervals':excluded,'fixtures':fixtures};(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Selected',len(fixtures),'unseen short utterances before inference.')
