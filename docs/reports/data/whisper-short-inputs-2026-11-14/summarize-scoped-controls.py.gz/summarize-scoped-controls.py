from pathlib import Path
import json
root=Path('/tmp/sillies-offline-20261114')

def selected(name):
 data=json.loads((root/(name+'.json')).read_text());assert data['complete'];assert len(data['results'])==data['expectedResults']
 return {r['id']:r for r in data['results'] if r['mode']=='baseline'}

def compare(old,new):
 a,b=selected(old),selected(new);assert a.keys()==b.keys();short=[];long=[];changed=[]
 for key,previous in a.items():
  candidate=b[key];assert previous['windows']==candidate['windows'];assert previous['reference']==candidate['reference'];assert not candidate['errors']
  traces=previous['inferenceWindows'];is_short=bool(traces) and all(t['sampleCount']<=16000 for t in traces)
  item={'id':key,'previousInputCounts':[t['sampleCount'] for t in traces],'candidateInputCounts':[t['sampleCount'] for t in candidate['inferenceWindows']],'equalInferenceTrace':traces==candidate['inferenceWindows'],'equalLongInferenceTrace':[t for t in traces if t['sampleCount']>16000]==[t for t in candidate['inferenceWindows'] if t['sampleCount']>16000],'equalHypothesis':previous['hypothesis']==candidate['hypothesis'],'previousHypothesis':previous['hypothesis'],'candidateHypothesis':candidate['hypothesis']}
  (short if is_short else long).append(item)
  if not item['equalHypothesis']:changed.append(item)
 return {'baseline':old,'candidate':new,'pairs':len(a),'observedShortInferenceCases':short,'otherCases':long,'changedHypotheses':changed}

result=[compare(*names) for names in [('baseline-short-holdout','final-short-holdout'),('baseline-short-noise','final-short-noise'),('baseline-fresh-short-noise','final-fresh-short-noise'),('baseline-meeting','final-meeting'),('baseline-development','final-development')]]
(root/'scoped-control-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for group in result:
 print(group['candidate'],group['pairs'],'short',len(group['observedShortInferenceCases']),'other',len(group['otherCases']),'changed hypotheses',len(group['changedHypotheses']),'all long traces equal',all(r['equalLongInferenceTrace'] for r in group['otherCases']+group['observedShortInferenceCases']))
