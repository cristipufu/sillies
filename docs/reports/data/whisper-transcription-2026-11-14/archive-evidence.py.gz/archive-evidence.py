"""Archive bounded qualification evidence, never audio, model weights or personal data."""
from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/sillies-whisper-20261114'); destination=Path('docs/reports/data/whisper-transcription-2026-11-14'); destination.mkdir(parents=True,exist_ok=True)
files={p.name:p for pattern in ['*.json','*.py'] for p in root.glob(pattern)}
for directory in ['source','fresh-source','next-source','validation-source','conditions','fresh-conditions','next-conditions','validation-conditions','meeting','continuous','noise-controls','noise-holdout']:
 for p in (root/directory).glob('*.json'): files[directory+'-'+p.name]=p
for source in sorted(Path('/tmp').glob('sillies-whisper-*.log')):
 files['logs-'+source.name]=source
index=destination/'checksums.json'
checksums=json.loads(index.read_text()) if index.exists() else {}
for name,metadata in checksums.items():
 retained=(destination/name).read_bytes()
 assert hashlib.sha256(retained).hexdigest()==metadata['sha256']
 assert hashlib.sha256(gzip.decompress(retained)).hexdigest()==metadata['sourceSHA256']
for name,source in sorted(files.items()):
 data=source.read_bytes()
 if len(data)>16*1024*1024: raise ValueError('Evidence exceeds per-file bound')
 target=destination/(name+'.gz'); target.write_bytes(gzip.compress(data,mtime=0))
 checksums[target.name]={'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'sourceSHA256':hashlib.sha256(data).hexdigest()}
assert sum(v['bytes'] for v in checksums.values())<=2*1024*1024
(destination/'checksums.json').write_text(json.dumps(checksums,indent=2)+'\n')
print(len(checksums),'artifacts,',sum(v['bytes'] for v in checksums.values()),'bytes')
