"""Remove only checksum-verified disposable inputs after the evidence archive is verified."""
from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
root=Path('/tmp/sillies-whisper-20261114')
archive=Path('docs/reports/data/whisper-transcription-2026-11-14')
index=json.loads((archive/'checksums.json').read_text())
assert Path('/tmp/sillies-whisper-cleanup-open-files.log').read_bytes()==b''
assert Path('/tmp/sillies-whisper-cleanup-lsof-errors.log').read_bytes()==b''
for name,meta in index.items():
 data=(archive/name).read_bytes()
 assert len(data)==meta['bytes']
 assert hashlib.sha256(data).hexdigest()==meta['sha256']
 assert hashlib.sha256(gzip.decompress(data)).hexdigest()==meta['sourceSHA256']
inputs=json.loads((root/'cleanup-input-inventory.json').read_text())
assert inputs['root']==str(root)
allowed=['source','fresh-source','next-source','validation-source','conditions','fresh-conditions','next-conditions','validation-conditions','meeting','continuous','noise-controls','noise-holdout','vad-windows']
actual=[]
for directory in inputs['directories']:
 assert directory in allowed
 p=root/directory
 assert p.parent==root and p.resolve().is_relative_to(root.resolve())
 for file in p.rglob('*'):
  assert not file.is_symlink()
  if file.is_file(): actual.append(str(file.relative_to(root)))
assert sorted(actual)==sorted(f['path'] for f in inputs['files'])
for f in inputs['files']:
 p=root/f['path']
 assert p.stat().st_size==f['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
 if p.suffix=='.json':
  item=archive/(p.relative_to(root).parts[0]+'-'+p.name+'.gz')
  assert gzip.decompress(item.read_bytes())==p.read_bytes()
executables=json.loads((root/'cleanup-executable-inventory.json').read_text())
for f in executables['executables']:
 p=root/f['path']
 assert p.parent==root
 assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
for f in executables['resourceLinks']:
 p=root/f['path']
 assert p.parent==root and p.is_symlink() and str(p.resolve())==f['target']
assert not [s for s in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines() if 'SpeechBenchmark-' in s]
for directory in inputs['directories']: shutil.rmtree(root/directory)
for f in executables['executables']: (root/f['path']).unlink()
for f in executables['resourceLinks']: (root/f['path']).unlink()
freed=sum(f['bytes'] for f in inputs['files'])+sum(f['bytes'] for f in executables['executables'])
record={'removedGeneratedFiles':len(inputs['files']),'removedCandidateExecutables':len(executables['executables']),'unlinkedOwnResourceLinks':len(executables['resourceLinks']),'removedBytes':freed,'verifiedEveryInputAndBinaryHash':True,'verifiedArchiveBeforeDeletion':True,'noOpenFilesOrRunningCandidates':True,'retainedOriginalAMISourceCache':True,'installedModelsAndPersonalVaultUntouched':True,'buildTreeNotSwept':True,'localAppBundles':['build/Sillies.app','build/Sillies.previous.app']}
(root/'cleanup-result.json').write_text(json.dumps(record,indent=2)+'\n')
print('Removed verified disposable inputs and binaries:',freed,'bytes; source manifests, results and receipts retained.')
