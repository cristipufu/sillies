"""Retain discovered selections and mandatory completion receipts from the final headless runs."""
from pathlib import Path
import json,re,hashlib
root=Path('/tmp/sillies-whisper-20261114'); categories={
 'focused':Path('/tmp/sillies-whisper-recovery-final-focused.log'),
 'check':Path('/tmp/sillies-whisper-recovery-check.log'),
 'stress':Path('/tmp/sillies-whisper-recovery-stress.log'),
 'race':Path('/tmp/sillies-whisper-recovery-race.log'),
 'acoustic-speech':Path('/tmp/sillies-whisper-qualified-level-speech.log'),
 'acoustic-noise-full':Path('/tmp/sillies-whisper-qualified-level-noise-full.log'),
 'acoustic-noise-prefix':Path('/tmp/sillies-whisper-qualified-level-noise-prefix.log'),
 'native-first-pass':Path('/tmp/sillies-whisper-recovery-native-v2.log'),
 'replay-and-provider':Path('/tmp/sillies-whisper-replay-scope-focused.log')}
result={}
for name,path in categories.items():
 text=path.read_text(); directories=re.findall(r'^Test receipts: (.+)$',text,re.M); runs=[]; total=0
 for directory in directories:
  d=Path(directory); verified=json.loads((d/'verified.json').read_text()); total+=sum(r['tests'] for r in verified)
  runs.append({'verified':verified,'selections':{p.name:json.loads(p.read_text()) for p in sorted(d.glob('*.suite.json'))}})
 declared=sum(int(n) for n in re.findall(r'Verified completion of (\d+) selected tests',text))
 assert runs and total==declared,(name,total,declared)
 assert 'Test verification failed' not in text and 'WARNING: ThreadSanitizer' not in text
 result[name]={'tests':total,'logSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'runs':runs}
(root/'final-test-receipts.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v['tests'] for k,v in result.items()})
