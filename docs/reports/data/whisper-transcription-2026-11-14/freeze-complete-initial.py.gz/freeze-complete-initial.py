from pathlib import Path
import shutil,hashlib,json,subprocess
root=Path('/tmp/sillies-whisper-20261114'); candidate=root/'SpeechBenchmark-complete-initial'
if candidate.exists(): raise ValueError('Candidate already pinned')
binary=Path('.build/release/SpeechBenchmark').resolve(); shutil.copy2(binary,candidate)
paths=[]
for folder in ['SilliesCore','SilliesSpeech','SilliesAudio','SilliesSpeechWhisper']:
 paths += list((Path('Sources')/folder).glob('*.swift'))
paths+=list(Path('Tools/SpeechBenchmark').glob('*.swift'))
paths += [Path(s) for s in ['Sources/SilliesApp/Skills/SpeechCapturePreparation.swift','Package.swift','Package.resolved','Benchmarks/Speech/score-quality.py','Benchmarks/Speech/prepare-quality.py','Benchmarks/Speech/prepare-fleurs.py','Vendor/AudioProcessing/VoiceActivity.cc','Vendor/AudioProcessing/include/VoiceActivity.h','Vendor/AudioProcessing/Package.swift','Vendor/AudioProcessing/README.md']]
sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
frozen={'baseCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binarySHA256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'binaryBytes':candidate.stat().st_size,'sources':sources,'candidateDefault':'adaptive with standard/amplified acoustic confirmation and a complete initial pass for detected speech, preserving native silence/confidence/fallback policy','decoderChanges':True}
(root/'frozen-complete-initial.json').write_text(json.dumps(frozen,indent=2)+'\n')
print('Pinned',candidate.name,frozen['binarySHA256'],len(sources),'source files',flush=True)
