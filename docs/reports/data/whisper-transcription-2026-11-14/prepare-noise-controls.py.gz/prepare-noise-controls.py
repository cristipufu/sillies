from pathlib import Path
import hashlib,importlib.util,json,random
root=Path('/tmp/sillies-whisper-20261114'); dest=root/'noise-controls'; dest.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('prepare',Path('Benchmarks/Speech/prepare-quality.py')); prepare=importlib.util.module_from_spec(spec); spec.loader.exec_module(prepare)
full=[]; partial=[]; fixtures=[]
for seed in [2,11,42,101,123,555,2026,2027]:
 for level in [0.0005,0.0018,0.015]:
  rng=random.Random(seed); data=[0.0]*8000+[rng.gauss(0,level) for _ in range(96000)]+[0.0]*19200
  for label,values,entries in [('full',data,full),('prefix',data[:32000],partial)]:
   identifier=f'noise-{seed}-{level}-{label}'; path=dest/(identifier+'.wav'); prepare.write_audio(path,values)
   entries.append({'id':identifier,'audio':path.as_uri(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'expectedSpeech':False})
  fixtures.append({'id':f'noise-{seed}-{level}','language':'en','split':'test','condition':'no-speech','file':f'noise-{seed}-{level}-full.wav','reference':'','sha256':full[-1]['sha256']})
for label,entries in [('full',full),('prefix',partial)]:
 (root/f'acoustic-noise-seeds-{label}.json').write_text(json.dumps({'fixtures':entries,'output':(root/f'acoustic-noise-seeds-{label}-results.json').as_uri()},indent=2)+'\n')
(dest/'manifest.json').write_text(json.dumps({'selection':'Eight fixed RNG seeds at three fixed Gaussian noise levels, declared before native acoustic results. Full and two-second prefix checks use the same samples.','fixtures':fixtures},indent=2)+'\n')
