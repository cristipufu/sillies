from pathlib import Path
import hashlib,importlib.util,json,random
root=Path('/tmp/sillies-whisper-20261114'); dest=root/'noise-holdout'; dest.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('prepare',Path('Benchmarks/Speech/prepare-quality.py')); prepare=importlib.util.module_from_spec(spec); spec.loader.exec_module(prepare)
seeds=[17,61,73,211,907,3001,65537,104729]; levels=[0.0007,0.0015,0.0025,0.0075,0.0125,0.02]; fixtures=[]
for seed in seeds:
 for level in levels:
  rng=random.Random(seed); data=[0.0]*8000+[rng.gauss(0,level) for _ in range(96000)]+[0.0]*19200
  identifier=f'noise-holdout-{seed}-{level}'; path=dest/(identifier+'.wav'); prepare.write_audio(path,data)
  fixtures.append({'id':identifier,'language':'en','split':'test','condition':'no-speech','file':path.name,'reference':'','sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seed':seed,'noiseStandardDeviation':level})
(dest/'manifest.json').write_text(json.dumps({'selection':'Eight new RNG seeds and six predeclared levels; selected after the candidate source/executable freeze and before any recognition of these inputs. Gaussian noise with the unchanged leading/trailing silence.','seeds':seeds,'levels':levels,'fixtures':fixtures},indent=2)+'\n')
print('Prepared',len(fixtures),'new checksum-pinned noise inputs')
