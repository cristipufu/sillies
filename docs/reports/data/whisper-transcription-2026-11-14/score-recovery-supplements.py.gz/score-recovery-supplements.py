"""Score predeclared supplementary subsets without changing any native hypothesis."""
from pathlib import Path
import hashlib,importlib.util,json
root=Path('/tmp/sillies-whisper-20261114'); path=root/'recovery-supplementary.json'; document=json.loads(path.read_text()); assert document['complete']
spec=importlib.util.spec_from_file_location('quality',Path('Benchmarks/Speech/score-quality.py')); quality=importlib.util.module_from_spec(spec); spec.loader.exec_module(quality)
selections={
 'paced':(6,lambda row:row['id'].endswith('::paced')),
 'automatic':(6,lambda row:row['id'].endswith('::automatic')),
 'meeting':(10,lambda row:row['id'].startswith('ami-') and row['condition']!='continuous-meeting'),
 'continuous':(1,lambda row:row['condition']=='continuous-meeting')}
summary={}
for name,(pairs,selected) in selections.items():
 rows=[row for row in document['results'] if selected(row)]; assert len(rows)==pairs*2
 subset={**document,'results':rows,'expectedResults':len(rows),'subset':name,'sourceReportSHA256':hashlib.sha256(path.read_bytes()).hexdigest()}
 score=quality.score(subset); score['sourceReportSHA256']=subset['sourceReportSHA256']; score['subset']=name
 (root/f'recovery-supplementary-{name}-score.json').write_text(json.dumps(score,indent=2)+'\n')
 summary[name]={'pairs':pairs,'wer':{mode:value['wer'] for mode,value in score['totals'].items()},'regressions':score['critical_regressions'],'subgroupRegressions':score['subgroup_regressions'],'regressionChecksPassed':score['regression_checks_passed']}
(root/'recovery-supplementary-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
