"""Select public speech without consulting recognizer outputs; preserve all input provenance."""
from pathlib import Path
import csv,gzip,hashlib,importlib.util,io,json,shutil,tarfile,urllib.request,wave
ROOT=Path('/tmp/sillies-whisper-20261114')
REVISION='70bb2e84b976b7e960aa89f1c648e09c59f894dd'
spec=importlib.util.spec_from_file_location('restore',Path('Benchmarks/Speech/prepare-fleurs.py'))
restore=importlib.util.module_from_spec(spec); spec.loader.exec_module(restore)
excluded={'en':set(),'ro':set()}; evidence=[]
for path in sorted(Path('docs/reports/data').glob('*/*json*')):
 try:
  raw=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes()
  document=json.loads(raw)
 except (ValueError,OSError): continue
 if not isinstance(document,dict): continue
 found=False
 rows=[row for key in ['fixtures','results'] if isinstance(document.get(key),list) for row in document[key] if isinstance(row,dict)]
 for f in rows:
  identifier=f.get('id','').split('::')[0]
  for language,locale in [('en','en_us'),('ro','ro_ro')]:
   prefix=locale+'-test-'
   if identifier.startswith(prefix): excluded[language].add(identifier[len(prefix):]); found=True
 if found: evidence.append({'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
dest=ROOT/'fresh-source'; dest.mkdir(exist_ok=False)
known=json.loads((ROOT/'source/manifest.json').read_text())
fixtures=[f for f in known['fixtures'] if f['split']=='dev']
for f in fixtures:
 target=dest/f['file']; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/'source'/f['file'],target)
for language,locale in [('en','en_us'),('ro','ro_ro')]:
 base=f'https://huggingface.co/datasets/google/fleurs/resolve/{REVISION}/data/{locale}'
 with urllib.request.urlopen(base+'/test.tsv',timeout=60) as r: tsv=r.read(4*1024*1024)
 (ROOT/(locale+'-test.tsv')).write_bytes(tsv)
 metadata={r[1]:r for r in csv.reader(io.StringIO(tsv.decode()),delimiter='\t')}
 selected=set(); archive_url=base+'/audio/test.tar.gz'
 with urllib.request.urlopen(archive_url,timeout=60) as response, tarfile.open(fileobj=response,mode='r|gz') as archive:
  for entry in archive:
   row=metadata.get(Path(entry.name).name)
   if not row or row[0] in excluded[language] or row[0] in selected: continue
   if not entry.isfile() or not 0<entry.size<=restore.MAX_SOURCE_BYTES: raise ValueError('Source outside bound')
   source=archive.extractfile(entry).read(restore.MAX_SOURCE_BYTES+1); audio=restore.canonical_pcm(source)
   with wave.open(io.BytesIO(audio)) as f: duration=f.getnframes()/f.getframerate()
   if not 3<=duration<=20: continue
   relative=f'{locale}/test/{row[1]}'; target=dest/relative; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(audio)
   fixtures.append({'id':f'{locale}-test-{row[0]}','language':language,'split':'test','text_id':row[0],'file':relative,'reference':row[2],'normalized_reference':row[3],'speaker_gender':row[6],'duration':duration,'sample_rate':16000,'sha256':hashlib.sha256(audio).hexdigest(),'source_sha256':hashlib.sha256(source).hexdigest(),'canonicalization':'Mono PCM16 at original sample rate; Float32 source quantized without gain change.','source_archive':archive_url,'source_member':entry.name})
   selected.add(row[0])
   if len(selected)==20: break
 if len(selected)!=20: raise ValueError('Insufficient unseen text IDs')
 print(language,'selected',len(selected),'excluded',len(excluded[language]),flush=True)
manifest={'dataset':'google/fleurs','revision':REVISION,'selection':'First 20 distinct eligible test text IDs per language in archive order, excluding every earlier archived cohort; mono 16kHz 3–20s. Inputs selected before this candidate produces any test output. Development recordings are restored unchanged.','excluded_language_text_ids':{k:sorted(v) for k,v in excluded.items()},'prior_evidence':evidence,'fixtures':fixtures}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('Selected',len(fixtures),'verified inputs',flush=True)
